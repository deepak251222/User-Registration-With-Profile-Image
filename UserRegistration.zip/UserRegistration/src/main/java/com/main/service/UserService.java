package com.main.service;

import org.springframework.web.multipart.MultipartFile;

import com.main.Entity.User;

public interface UserService {
	
	public User add(User user);
	
}
